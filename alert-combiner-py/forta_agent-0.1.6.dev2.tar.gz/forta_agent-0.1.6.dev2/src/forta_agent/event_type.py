from enum import IntEnum


class EventType(IntEnum):
    BLOCK = 0
    REORG = 1
